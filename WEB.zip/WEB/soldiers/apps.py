from django.apps import AppConfig


class SoldiersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'soldiers'
    verbose_name = 'Преподаватели'